<?php
/* =========================================================
   MURAD AI — settings (PRIVATE: never share this file)
   ========================================================= */
return [

    // 1) Paste your free API keys here. One is enough; two gives a backup.
    //    Groq:    https://console.groq.com/keys
    //    Gemini:  https://aistudio.google.com/apikey
    'api_keys' => [
        'groq'       => 'PASTE_YOUR_GROQ_KEY_HERE',
        'gemini'     => '',
        'openrouter' => '',
    ],

    // 2) Which provider to try first. If it fails, the next one is used.
    'order' => ['groq', 'gemini', 'openrouter'],

    // 3) Models for normal text chat (tried from left to right).
    //    If a provider retires a model, just replace its name here.
    'models' => [
        'groq'       => ['openai/gpt-oss-120b', 'llama-3.3-70b-versatile', 'openai/gpt-oss-20b'],
        'gemini'     => ['gemini-2.5-flash', 'gemini-2.5-flash-lite'],
        'openrouter' => ['openrouter/free'],
    ],

    // 4) Models that can SEE images (photos, screenshots, scanned PDFs).
    'vision_models' => [
        'gemini'     => ['gemini-2.5-flash', 'gemini-2.5-flash-lite'],
        'groq'       => ['meta-llama/llama-4-scout-17b-16e-instruct'],
        'openrouter' => ['openrouter/free'],
    ],

    // 5) ACCOUNTS — let other people sign up and keep their own chats.
    'accounts' => [
        // Turn the whole account system on or off.
        'enabled'       => true,
        // Allow new people to create an account.
        'allow_signup'  => true,
        // true  = nobody can chat without signing in (protects your free limit)
        // false = visitors may also continue as a guest
        'require_login' => false,
        // Set a word here and only people who know it can create an account.
        'invite_code'   => '',
        // Stop accepting new accounts after this many.
        'max_users'     => 50,
        // Messages a guest may send per hour. Signed-in people get the
        // full limit below. 0 = guests cannot chat at all.
        'guest_messages_per_hour' => 50,
        // Most saved chat data per account, in megabytes.
        'max_data_mb'   => 4,
    ],

    // 6) Extra passcode for the whole site (usually leave empty; use accounts).
    'passcode' => '',

    // 7) Max messages one visitor can send per hour (0 = no limit).
    'max_requests_per_hour' => 200,

    // 8) Longest answer the AI may write (in tokens, ~0.75 words each).
    'max_tokens' => 4096,
];
