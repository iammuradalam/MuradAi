<?php
/* =========================================================
   MURAD AI — shared helpers (config, storage, accounts)
   ========================================================= */
declare(strict_types=1);

function mai_out(int $code, array $data): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function mai_config(): array {
    static $c = null;
    if ($c === null) {
        $f = __DIR__ . '/config.php';
        $c = is_file($f) ? (array)(require $f) : [];
    }
    return $c;
}

function mai_acc(string $key, $default = null) {
    $a = mai_config()['accounts'] ?? [];
    return $a[$key] ?? $default;
}

/* Folder for accounts and saved chats. Tries a folder ABOVE the website
   (not reachable from the web) first, then a protected folder inside it. */
function mai_dir(): string {
    static $dir = null;
    if ($dir !== null) return $dir;
    foreach ([dirname(__DIR__) . '/muradai-data', __DIR__ . '/_data'] as $c) {
        if (!is_dir($c)) @mkdir($c, 0700, true);
        if (is_dir($c) && is_writable($c)) {
            if (!is_file($c . '/.htaccess')) {
                @file_put_contents($c . '/.htaccess', "Require all denied\nDeny from all\nOptions -Indexes\n");
            }
            foreach (['users', 'chats', 'limits'] as $sub) {
                if (!is_dir($c . '/' . $sub)) @mkdir($c . '/' . $sub, 0700, true);
            }
            return $dir = $c;
        }
    }
    return $dir = '';
}

function mai_accounts_available(): bool {
    return mai_acc('enabled', true) && mai_dir() !== '';
}

function mai_read_json(string $file): ?array {
    if (!is_file($file)) return null;
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') return null;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : null;
}

function mai_write_json(string $file, array $data): bool {
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    $ok = @file_put_contents($tmp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    if ($ok === false) { @unlink($tmp); return false; }
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    return true;
}

/* ---------- accounts ---------- */

function mai_email_ok(string $e): bool {
    return strlen($e) <= 190 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}

function mai_user_file(string $email): string {
    return mai_dir() . '/users/' . hash('sha256', strtolower(trim($email))) . '.json';
}

function mai_user_by_id(string $id): ?array {
    if (!preg_match('/^[a-f0-9]{16}$/', $id)) return null;
    foreach ((glob(mai_dir() . '/users/*.json') ?: []) as $f) {
        $u = mai_read_json($f);
        if ($u && ($u['id'] ?? '') === $id) return $u;
    }
    return null;
}

function mai_user_count(): int {
    return count(glob(mai_dir() . '/users/*.json') ?: []);
}

function mai_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    @session_set_cookie_params([
        'lifetime' => 60 * 60 * 24 * 30,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $https,
    ]);
    @session_name('maisess');
    @session_start();
}

/** The signed-in user, or null. Closes the session lock straight away. */
function mai_current_user(): ?array {
    static $u = false;
    if ($u !== false) return $u;
    if (!mai_accounts_available()) return $u = null;
    mai_session();
    $id = (string)($_SESSION['uid'] ?? '');
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    return $u = ($id === '' ? null : mai_user_by_id($id));
}

function mai_public_user(?array $u): ?array {
    return $u ? ['email' => $u['email'] ?? '', 'name' => $u['name'] ?? '', 'created' => $u['created'] ?? null] : null;
}

/* ---------- simple counters (rate limiting) ---------- */

function mai_hits(string $key, int $window, int $max, bool $count = true): bool {
    $dir = mai_dir();
    if ($dir === '') return true; // no storage: don't block
    $file = $dir . '/limits/' . hash('sha256', $key) . '.json';
    $now = time();
    $hits = mai_read_json($file) ?: [];
    $hits = array_values(array_filter($hits, fn($t) => is_int($t) && $t > $now - $window));
    if (count($hits) >= $max) return false;
    if ($count) { $hits[] = $now; mai_write_json($file, $hits); }
    if (mt_rand(1, 60) === 1) {
        foreach ((glob($dir . '/limits/*.json') ?: []) as $f) {
            if (@filemtime($f) < $now - 86400) @unlink($f);
        }
    }
    return true;
}

function mai_ip(): string {
    return (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
}

function mai_body(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') return [];
    $j = json_decode($raw, true);
    return is_array($j) ? $j : [];
}
