<?php
/* =========================================================
   MURAD AI — server proxy
   Keeps your API key secret on the server and forwards chat
   requests to a free AI provider. If one provider or model
   fails (limit reached, model removed), it tries the next.
   ========================================================= */
declare(strict_types=1);
error_reporting(0);
require __DIR__ . '/lib.php';

$config = mai_config();

$PROVIDERS = [
    'groq'       => 'https://api.groq.com/openai/v1/chat/completions',
    'gemini'     => 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    'openrouter' => 'https://openrouter.ai/api/v1/chat/completions',
];

function key_for(array $config, string $p): string {
    $k = trim((string)($config['api_keys'][$p] ?? ''));
    return (stripos($k, 'PASTE') !== false) ? '' : $k;
}

/* ---------- GET: health check ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $have = [];
    foreach (($config['order'] ?? []) as $p) if (key_for($config, $p) !== '') $have[] = $p;
    mai_out(200, [
        'ok' => true, 'name' => 'Murad AI',
        'providers' => $have,
        'curl' => function_exists('curl_init'),
        'passcode_required' => ($config['passcode'] ?? '') !== '',
        'accounts' => mai_accounts_available(),
        'storage' => mai_dir() !== '',
    ]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') mai_out(405, ['error' => 'Method not allowed']);
if (!function_exists('curl_init')) mai_out(500, ['error' => 'PHP cURL is not available on this server.']);

/* ---------- who is asking ---------- */
$user = mai_current_user();
if (!$user && mai_accounts_available() && mai_acc('require_login', false)) {
    mai_out(401, ['error' => 'Please sign in to use Murad AI.']);
}

/* ---------- read & validate ---------- */
$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') mai_out(400, ['error' => 'Empty request (the message may be too large for this server).']);
if (strlen($raw) > 12 * 1024 * 1024) mai_out(413, ['error' => 'Request too large. Try fewer or smaller files.']);
$in = json_decode($raw, true);
if (!is_array($in) || !isset($in['messages']) || !is_array($in['messages'])) mai_out(400, ['error' => 'Bad request.']);

$pass = (string)($config['passcode'] ?? '');
if ($pass !== '' && !hash_equals($pass, (string)($in['passcode'] ?? ''))) {
    mai_out(401, ['error' => 'Wrong or missing passcode. Open Settings and enter the passcode.']);
}

$messages = [];
$hasImages = false;
foreach (array_slice($in['messages'], -40) as $m) {
    if (!is_array($m)) continue;
    $role = $m['role'] ?? '';
    if (!in_array($role, ['system', 'user', 'assistant'], true)) continue;
    $c = $m['content'] ?? '';
    if (is_string($c)) {
        $messages[] = ['role' => $role, 'content' => mb_substr($c, 0, 400000)];
    } elseif (is_array($c) && $role === 'user') {
        $parts = [];
        foreach ($c as $part) {
            if (!is_array($part)) continue;
            if (($part['type'] ?? '') === 'text' && is_string($part['text'] ?? null)) {
                $parts[] = ['type' => 'text', 'text' => mb_substr($part['text'], 0, 400000)];
            } elseif (($part['type'] ?? '') === 'image_url') {
                $url = (string)($part['image_url']['url'] ?? '');
                if (preg_match('#^data:image/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$#', $url)) {
                    $parts[] = ['type' => 'image_url', 'image_url' => ['url' => $url]];
                    $hasImages = true;
                }
            }
        }
        if ($parts) $messages[] = ['role' => 'user', 'content' => $parts];
    }
}
if (!$messages) mai_out(400, ['error' => 'No messages.']);

/* ---------- rate limit (per account if signed in, otherwise per visitor) ---------- */
$limit = (int)($config['max_requests_per_hour'] ?? 0);
$guestLimit = (int)mai_acc('guest_messages_per_hour', 50);
$isGuest = !$user && mai_accounts_available();
if ($isGuest) {
    if ($guestLimit <= 0) mai_out(401, ['error' => 'Please create a free account to chat.', 'signin' => true]);
    $limit = $guestLimit;
} elseif ($limit > 0 && $limit < $guestLimit) {
    $limit = $guestLimit;   // people with an account never get less than guests
}
if ($limit > 0) {
    $who = $user ? 'u:' . $user['id'] : 'ip:' . mai_ip();
    if (!mai_hits('chat:' . $who, 3600, $limit)) {
        mai_out(429, $isGuest
            ? ['error' => 'Guests can send ' . $limit . ' messages an hour. Create a free account to keep going — your chats get saved too.', 'signin' => true]
            : ['error' => 'Too many messages this hour. Please try again a little later.']);
    }
}

/* ---------- build the list of (provider, model) to try ---------- */
$kind = $hasImages ? 'vision_models' : 'models';
$candidates = [];
foreach (($config['order'] ?? array_keys($PROVIDERS)) as $p) {
    if (!isset($PROVIDERS[$p]) || key_for($config, $p) === '') continue;
    foreach ((array)($config[$kind][$p] ?? []) as $model) $candidates[] = [$p, (string)$model];
}
if (!$candidates) {
    mai_out(500, ['error' => $hasImages
        ? 'No vision model is set up on the server, so images and scanned PDFs cannot be read yet. Add a Gemini or Groq key in config.php.'
        : 'No API key is set on the server yet. Open config.php and paste your free key.']);
}

/* ---------- call providers with failover ---------- */
$lastError = 'Unknown error';
foreach ($candidates as [$p, $model]) {
    $payload = ['model' => $model, 'messages' => $messages, 'temperature' => 0.7, 'max_tokens' => (int)($config['max_tokens'] ?? 4096)];
    $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . key_for($config, $p)];
    if ($p === 'openrouter') { $headers[] = 'HTTP-Referer: https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'); $headers[] = 'X-Title: Murad AI'; }

    $ch = curl_init($PROVIDERS[$p]);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 55,
    ]);
    $body = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    if ($body === false) { $lastError = "$p: could not connect ($cerr)"; continue; }
    $j = json_decode((string)$body, true);
    if ($status === 200 && is_array($j)) {
        $text = $j['choices'][0]['message']['content'] ?? '';
        if (is_array($text)) { $t = ''; foreach ($text as $part) $t .= is_array($part) ? ($part['text'] ?? '') : (string)$part; $text = $t; }
        if (is_string($text) && trim($text) !== '') mai_out(200, ['reply' => $text, 'model' => $model]);
        $lastError = "$p/$model returned an empty answer";
        continue;
    }
    $msg = '';
    if (is_array($j)) $msg = (string)($j['error']['message'] ?? ($j[0]['error']['message'] ?? ''));
    $lastError = "$p/$model: " . ($msg !== '' ? mb_substr($msg, 0, 300) : "HTTP $status");
    // any failure -> try the next model/provider
}

$friendly = (stripos($lastError, 'rate') !== false || stripos($lastError, 'quota') !== false || stripos($lastError, '429') !== false)
    ? 'The free limit is used up for the moment. Wait a minute and try again.'
    : 'The AI service could not answer right now.';
mai_out(502, ['error' => $friendly . ' (' . $lastError . ')']);
