<?php
/* =========================================================
   MURAD AI — accounts: create, sign in, sign out
   ========================================================= */
declare(strict_types=1);
error_reporting(0);
require __DIR__ . '/lib.php';

$action = (string)($_GET['action'] ?? 'me');

/* ---------- status ---------- */
if ($action === 'me') {
    if (!mai_accounts_available()) {
        mai_out(200, ['accounts' => false, 'user' => null,
            'reason' => mai_acc('enabled', true) ? 'storage_unavailable' : 'disabled']);
    }
    $u = mai_current_user();
    mai_out(200, [
        'accounts' => true,
        'user' => mai_public_user($u),
        'allow_signup' => (bool)mai_acc('allow_signup', true) && mai_user_count() < (int)mai_acc('max_users', 50),
        'require_login' => (bool)mai_acc('require_login', false),
        'invite_required' => trim((string)mai_acc('invite_code', '')) !== '',
        'guest_limit' => (int)mai_acc('guest_messages_per_hour', 50),
    ]);
}

if (!mai_accounts_available()) mai_out(503, ['error' => 'Accounts are not available on this server.']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') mai_out(405, ['error' => 'Method not allowed']);

$in = mai_body();
$email = strtolower(trim((string)($in['email'] ?? '')));
$pass  = (string)($in['password'] ?? '');

/* ---------- sign out ---------- */
if ($action === 'logout') {
    mai_session();
    $_SESSION = [];
    @session_destroy();
    mai_out(200, ['ok' => true]);
}

/* ---------- create account ---------- */
if ($action === 'signup') {
    if (!mai_acc('allow_signup', true)) mai_out(403, ['error' => 'New accounts are closed on this site.']);
    if (!mai_hits('signup:' . mai_ip(), 3600, 5)) mai_out(429, ['error' => 'Too many sign-up attempts. Please try again later.']);

    $code = trim((string)mai_acc('invite_code', ''));
    if ($code !== '' && !hash_equals($code, trim((string)($in['invite'] ?? '')))) {
        mai_out(403, ['error' => 'That invite code is not correct.']);
    }
    if (mai_user_count() >= (int)mai_acc('max_users', 50)) {
        mai_out(403, ['error' => 'This site has reached its limit of accounts.']);
    }
    if (!mai_email_ok($email)) mai_out(400, ['error' => 'Please enter a valid email address.']);
    if (strlen($pass) < 8) mai_out(400, ['error' => 'Your password needs at least 8 characters.']);
    if (strlen($pass) > 200) mai_out(400, ['error' => 'That password is too long.']);

    $file = mai_user_file($email);
    if (is_file($file)) mai_out(409, ['error' => 'An account with this email already exists. Try signing in.']);

    $user = [
        'id' => bin2hex(random_bytes(8)),
        'email' => $email,
        'name' => mb_substr(trim((string)($in['name'] ?? '')), 0, 60),
        'hash' => password_hash($pass, PASSWORD_DEFAULT),
        'created' => gmdate('c'),
    ];
    if (!mai_write_json($file, $user)) mai_out(500, ['error' => 'The account could not be saved on the server.']);

    mai_session();
    session_regenerate_id(true);
    $_SESSION['uid'] = $user['id'];
    session_write_close();
    mai_out(200, ['ok' => true, 'user' => mai_public_user($user)]);
}

/* ---------- sign in ---------- */
if ($action === 'login') {
    if (!mai_hits('login:' . mai_ip(), 900, 12)) {
        mai_out(429, ['error' => 'Too many sign-in attempts. Please wait a few minutes.']);
    }
    $user = mai_email_ok($email) ? mai_read_json(mai_user_file($email)) : null;
    if (!$user || !password_verify($pass, (string)($user['hash'] ?? ''))) {
        usleep(300000);
        mai_out(401, ['error' => 'Wrong email or password.']);
    }
    if (password_needs_rehash((string)$user['hash'], PASSWORD_DEFAULT)) {
        $user['hash'] = password_hash($pass, PASSWORD_DEFAULT);
        mai_write_json(mai_user_file($email), $user);
    }
    mai_session();
    session_regenerate_id(true);
    $_SESSION['uid'] = $user['id'];
    session_write_close();
    mai_out(200, ['ok' => true, 'user' => mai_public_user($user)]);
}

mai_out(400, ['error' => 'Unknown action.']);
