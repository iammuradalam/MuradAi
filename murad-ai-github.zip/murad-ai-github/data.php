<?php
/* =========================================================
   MURAD AI — chats and memories saved to an account
   GET  -> everything stored for the signed-in user
   POST -> replaces it
   ========================================================= */
declare(strict_types=1);
error_reporting(0);
require __DIR__ . '/lib.php';

if (!mai_accounts_available()) mai_out(503, ['error' => 'Saving to an account is not available on this server.']);

$user = mai_current_user();
if (!$user) mai_out(401, ['error' => 'Please sign in first.']);

$file = mai_dir() . '/chats/' . $user['id'] . '.json';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $d = mai_read_json($file) ?: [];
    mai_out(200, [
        'chats' => $d['chats'] ?? [],
        'memories' => $d['memories'] ?? [],
        'updated' => $d['updated'] ?? null,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') mai_out(405, ['error' => 'Method not allowed']);

$maxBytes = max(1, (int)mai_acc('max_data_mb', 4)) * 1024 * 1024;
$raw = file_get_contents('php://input');
if ($raw === false) mai_out(400, ['error' => 'Nothing received.']);
if (strlen($raw) > $maxBytes) {
    mai_out(413, ['error' => 'Your saved chats are too large. Delete some old chats, or export and clear them.']);
}

$in = json_decode($raw, true);
if (!is_array($in) || !is_array($in['chats'] ?? null) || !is_array($in['memories'] ?? null)) {
    mai_out(400, ['error' => 'Bad request.']);
}
if (count($in['chats']) > 500) mai_out(413, ['error' => 'Too many chats to save (maximum 500).']);

if (!mai_write_json($file, [
    'chats' => $in['chats'],
    'memories' => array_slice($in['memories'], 0, 500),
    'updated' => gmdate('c'),
])) {
    mai_out(500, ['error' => 'The server could not save your chats.']);
}

mai_out(200, ['ok' => true, 'saved' => count($in['chats'])]);
